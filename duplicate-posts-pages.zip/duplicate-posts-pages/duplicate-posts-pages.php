<?php
/*
Plugin Name: Duplicate Posts and Pages
Description: A simple plugin to duplicate posts and pages in WordPress.
Version: 1.0
Author: Your Name
*/

// Duplicate Post/Page Button
function duplicate_post_page_button($actions, $post) {
    if (current_user_can('edit_posts')) {
        $actions['duplicate'] = '<a href="' . admin_url("admin.php?action=duplicate_post_page&post={$post->ID}") . '" title="Duplicate this item" rel="permalink">Duplicate</a>';
    }
    return $actions;
}

add_filter('page_row_actions', 'duplicate_post_page_button', 10, 2);
add_filter('post_row_actions', 'duplicate_post_page_button', 10, 2);

// Duplicate Post/Page Action
function duplicate_post_page_action() {
    if (isset($_GET['action']) && $_GET['action'] === 'duplicate_post_page' && isset($_GET['post'])) {
        $post_id = $_GET['post'];

        // Check if the user has permission to edit this post
        if (!current_user_can('edit_post', $post_id)) {
            wp_die('Permission Denied');
        }

        // Get the post to duplicate
        $post_to_duplicate = get_post($post_id);

        // Duplicate the post data
        $new_post_data = array(
            'post_title' => $post_to_duplicate->post_title . ' (Copy)',
            'post_content' => $post_to_duplicate->post_content,
            'post_status' => $post_to_duplicate->post_status,
            'post_type' => $post_to_duplicate->post_type,
        );

        // Insert the new post into the database
        $new_post_id = wp_insert_post($new_post_data);

        // Duplicate post meta
        $post_meta = get_post_meta($post_id);
        foreach ($post_meta as $key => $value) {
            update_post_meta($new_post_id, $key, $value[0]);
        }

        // Redirect to the new post
        wp_redirect(admin_url("post.php?action=edit&post={$new_post_id}"));
        exit;
    }
}

add_action('admin_action_duplicate_post_page', 'duplicate_post_page_action');
